import { load } from "./route.js";
import getelemen from "./observer.js";

// — Helper —

const toCamelCase = (str) =>
  str
    .split("-")
    .map((word, i) => (i === 0 ? word : word.charAt(0).toUpperCase() + word.slice(1)))
    .join("");

const toFileName = (str) =>
  str
    .split(/(?=[A-Z])/)
    .map((w) => w.toLowerCase())
    .join("-");

// — Parse komponen dari HTML string —

function parseComponents(htmlString, fileName) {
  const parser = new DOMParser();
  const doc = parser.parseFromString(htmlString, "text/html");
  const body = doc.body;

  // Cek apakah ada tag comp-* di dalam
  const compTags = Array.from(body.children).filter((el) =>
    el.tagName.toLowerCase().startsWith("comp-")
  );

  const result = {};

  if (compTags.length === 0) {
    // Satu komponen — nama dari file
    const name = toCamelCase(fileName);
    result[name] = body.innerHTML.trim();
  } else {
    // Banyak komponen — nama dari tag comp-*
    compTags.forEach((el) => {
      const tagName = el.tagName.toLowerCase(); // misal: comp-card, comp-nav-bar
      const rawName = tagName.slice("comp-".length); // card, nav-bar
      const name = toCamelCase(rawName); // card, navBar
      result[name] = el.innerHTML.trim();
    });
  }

  return result;
}

// — Cek apakah komponen punya slot data (this-*) —

function hasDataSlot(htmlString) {
  return /<this-[a-zA-Z][a-zA-Z0-9-]*\s*\/>/i.test(htmlString);
}

// — Inject data ke slot this-* —

function injectData(htmlString, data) {
  let result = htmlString;
  for (const [key, value] of Object.entries(data)) {
    const regex = new RegExp(`<this-${key}\\s*\\/>`, "gi");
    result = result.replace(regex, value);
  }
  return result;
}

// — Buat proxy untuk satu komponen —

function createComponentProxy(htmlString) {
  const withData = hasDataSlot(htmlString);

  // Object dasar komponen
  const comp = {
    _html: htmlString,
    _withData: withData,
  };

  return new Proxy(comp, {
    get(target, key) {
      if (typeof key !== "string") return undefined;

      // Kalau dipanggil sebagai fungsi dengan data
      if (key === Symbol.toPrimitive || key === "then") return undefined;

      // Akses elemen di dalam komponen
      return new Proxy(
        {},
        {
          get(_, elKey) {
            if (typeof elKey !== "string") return undefined;
            // Cari elemen di dalam HTML komponen berdasarkan tag / class / id
            // Dibuat scoped ke dalam komponen
            return getelemen.el(`[data-comp-scope] ${elKey}`) ||
              getelemen.el(`[data-comp-scope] .${elKey}`) ||
              getelemen.el(`[data-comp-scope] #${elKey}`);
          },
        }
      );
    },
    apply(target, thisArg, args) {
      if (!target._withData) {
        throw new Error(`[component] Komponen ini tidak memiliki slot data (this-*).`);
      }
      const data = args[0] ?? {};
      return injectData(target._html, data);
    },
  });
}

// — Registry internal —

const componentRegistry = {};

// — Load dan parse file komponen —

async function loadComponent(fileName) {
  if (componentRegistry[fileName]) return componentRegistry[fileName];

  const html = await load(`/page/template/${fileName}.html`);
  const parsed = parseComponents(html, fileName);

  const result = {};

  for (const [name, htmlString] of Object.entries(parsed)) {
    const withData = hasDataSlot(htmlString);

    if (withData) {
      // Komponen dengan data — callable proxy
      result[name] = new Proxy(
        function (data = {}) {
          return injectData(htmlString, data);
        },
        {
          get(fn, elKey) {
            if (typeof elKey !== "string") return undefined;
            if (elKey === "then") return undefined;
            // Akses elemen langsung lewat getElement
            return (
              getelemen.el(elKey) ||
              getelemen.el(`.${elKey}`) ||
              getelemen.el(`#${elKey}`)
            );
          },
        }
      );
    } else {
      // Komponen statis — langsung object dengan akses elemen
      result[name] = new Proxy(
        { _html: htmlString },
        {
          get(target, elKey) {
            if (typeof elKey !== "string") return undefined;
            if (elKey === "_html") return target._html;
            if (elKey === "then") return undefined;
            return (
              getelemen.el(elKey) ||
              getelemen.el(`.${elKey}`) ||
              getelemen.el(`#${elKey}`)
            );
          },
        }
      );
    }
  }

  componentRegistry[fileName] = result;
  return result;
}

// — Proxy utama yang di-export —
// Menangkap: useComponentFromNamaFile()

export const component = new Proxy(
  {},
  {
    get(_, key) {
      if (typeof key !== "string") return undefined;
      if (!key.startsWith("useComponentFrom")) return undefined;

      const rawName = key.slice("useComponentFrom".length); // "Ui", "NavBar", dll
      const fileName = toFileName(rawName); // "ui", "nav-bar", dll

      return async () => {
        const components = await loadComponent(fileName);

        // Return proxy object yang bisa akses komponen langsung
        return new Proxy(components, {
          get(target, compKey) {
            if (typeof compKey !== "string") return undefined;
            if (compKey in target) return target[compKey];
            throw new Error(`[component] Komponen "${compKey}" tidak ditemukan di file "${fileName}.html".`);
          },
        });
      };
    },
  }
);

import getelemen from "./system/observer.js";
import { registerPage } from "./system/registry.js";
import { component } from "./system/component.js";

class Helper {
  getElement(...selector) {
    if (selector.length !== 1) {
      return selector.map((item) => getelemen.el(item));
    }
    return getelemen.el(selector[0]);
  }
  register(name, intFunc) {
    return registerPage(name, intFunc);
  }
}

const helperInstance = new Helper();

const helper = new Proxy(helperInstance, {
  get(target, key) {
    if (key in target)
      return typeof target[key] === "function"
        ? target[key].bind(target)
        : target[key];
    if (typeof key === "string" && key.startsWith("useComponentFrom"))
      return component[key];
    return undefined;
  },
});

export default helper;

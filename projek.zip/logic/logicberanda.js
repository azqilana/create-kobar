import Kobar from "../index.js";

Kobar.register("beranda", async () => {
  const [
    judul,
    subjudul,
    input,
    tombol,
    tombolToggle,
    status,
    card,
    cardini,
    kartuPesan,
  ] = Kobar.getElement(
    "#judul",
    "#subjudul",
    "#input",
    "#tombol",
    "#tombolToggle",
    "#status",
    ".card",
    ".cardini",
    "all:.kartu-profil",
  );

  const { kartuProfil, badge } = await Kobar.useComponentFromKartu();
  console.log(kartuProfil);
  console.log(badge);

  const comp = await Kobar.useComponentFromKartu();
  console.log(comp);

  let data;

  tombol
    .onTheStyleBackgroundColorItsBlue()
    .onTheStyleColorItsWhite()
    .onTheStyleWidthIts100Pct()
    .onTheClassActive();

  // Hapus error saat input difokus
  input.onTheFocus(() => {
    input.offTheClassError();
    status.onTheText(" ");
  });

  kartuPesan.onTheEach((e) => {
    e.onTheStyleBackgroundColorItsBlue();
    e.onTheStylePaddingIts10px();
    e.onTheStyleMarginIts10px();
    e.onTheStyleBorderRadiusIts10px();
    e.onTheStyleBackgroundColorItsYellowgreen();
  });

  cardini
    .onTheStylePaddingIts10px()
    .onTheStyleMarginIts10px()
    .onTheStyleTextAlignItsCenter()
    .onTheStyleBorderRadiusIts10px()
    .onTheStyleBackgroundColorItsGreen();

  judul
    .onTheStyleBackgroundColorItsBlack()
    .onTheStyleColorItsWhite()
    .onTheStylePaddingIts10px()
    .onTheStyleBorderRadiusIts10px();

  const img = Kobar.build({
    tag: "img",
    class: "gambar",
    attr: { src: "./assets/logo.png" },
  }).done();

  judul.domInsertAdjacentHTML("beforeBegin", img.string);
  console.log(img);

  const gambar = Kobar.getElement(".gambar");
  gambar.onTheStyleWidthIts100px();

  tombol.onTheClick(async () => {
    const nilai = input.htmlValue();
    console.log(nilai);

    if (!nilai) {
      input.onTheClassError();
      status.onTheTextIsiDuluNamaMu();
      return;
    }

    kartuPesan.onTheEach((e) => {
      e.toggleTheStyleBackgroundColorItsYellowgreenWithCyan();
    });

    input.domValue("");
    console.log(nilai);

    const itemBaru = {
      nama: nilai,
      pesan: "Terima Kasih Atas Kehadiran Nya",
      url: "https://azqilana.my.id",
    };

    data = itemBaru;

    const kartu = await kartuProfil.data(itemBaru);
    cardini.onTheHtml(kartu);
    cardini.toggleTheStyleBackgroundColorItsGreenWithBlue();
    cardini.toggleTheStyleColorItsBlueWithDarkgreen();

    judul.changeTheText(`Hai, ${nilai}!`);

    subjudul.onTheTextSelamatDatang();

    status
      .onTheTextBerhasil()
      .onTheClassAktif()
      .onTheStyleColorItsGreenyellow()
      .onTheStyleBackgroundColorItsBlack()
      .onTheStylePaddingIts20px();
  });

  // Toggle warna judul
  tombolToggle.onTheClick(() => {
    tombolToggle.toggleTheClassOnWithOff();
    judul.toggleTheStyleColorItsWhiteWithBlack();
    judul.toggleTheStyleBackgroundColorItsBlackWithWhite();
  });
});
